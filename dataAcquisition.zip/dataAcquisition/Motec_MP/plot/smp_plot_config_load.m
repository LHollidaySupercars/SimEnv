function plots = smp_plot_config_load(filepath, sheet)
% SMP_PLOT_CONFIG_LOAD  Read a plot configuration Excel sheet.
%
% Expected columns (order flexible, names matched case-insensitively):
%   plotName | plotType | mathFunction | xAxis | yAxis1 | yAxis2 | yAxis3 | yAxis4 | zAxis | colours | differentiator
%
% Usage:
%   plots = smp_plot_config_load('C:\SMP\config\plot_config.xlsx')
%   plots = smp_plot_config_load('C:\SMP\config\plot_config.xlsx', 'Plots')
%
% Returns struct array, one element per row:
%   .name           char    plot title
%   .type           char    'scatter'|'line'|'boxplot'|'violin'|'histogram'|'timeseries'
%   .math_fn        char    'max'|'min'|'mean'|'variance'|'derivative'|'integral'
%   .x_axis         char    xAxis channel / keyword
%   .y_channels     cell    non-empty yAxis values
%   .z_axis         char    zAxis channel (reserved for surface plots)
%   .colour_mode    char    'manufacturer'|'driver'|'team'
%   .differentiator char    'shapes'|'colours'|'none'

    if nargin < 2 || isempty(sheet)
        sheet = 1;
    end

    if ~exist(filepath, 'file')
        error('smp_plot_config_load: File not found: %s', filepath);
    end

    T = readtable(filepath, 'Sheet', sheet);
    fprintf('smp_plot_config_load: %d plot definition(s) found.\n', height(T));

    vn = T.Properties.VariableNames;

    % ---- Column detection ----
    col_name  = find_col(vn, {'plotName','plot name','name'});
    col_type  = find_col(vn, {'plotType','plotTye','plot type','type'});
    col_math  = find_col(vn, {'mathFunction','math function','math','function'});
    col_x     = find_col(vn, {'xAxis','x axis','x'});
    col_y1    = find_col(vn, {'yAxis1','y axis1','y1','yAxis'});
    col_y2    = find_col(vn, {'yAxis2','y axis2','y2'});
    col_y3    = find_col(vn, {'yAxis3','y axis3','y3'});
    col_y4    = find_col(vn, {'yAxis4','y axis4','y4'});
    col_z     = find_col(vn, {'zAxis','z axis','z'});
    col_col   = find_col(vn, {'colours','colors','colour','color','colourMode'});
    col_diff  = find_col(vn, {'differentiator','diff','differentiate'});
    col_sec   = find_col(vn, {'useSecondary','secondary','secondaryAxis','use secondary'});
    col_filt  = find_col(vn, {'plotFilter','filter','plotfilter'});

    plots = struct('name',{}, 'type',{}, 'math_fn',{}, 'x_axis',{}, ...
                   'y_channels',{}, 'z_axis',{}, 'colour_mode',{}, ...
                   'differentiator',{}, 'use_secondary',{}, 'plot_filter',{});

    for r = 1:height(T)
        p.name           = get_str(T, r, col_name);
        p.type           = lower(strtrim(get_str(T, r, col_type)));
        p.math_fn        = lower(strtrim(get_str(T, r, col_math)));
        p.x_axis         = strtrim(get_str(T, r, col_x));
        p.z_axis         = strtrim(get_str(T, r, col_z));
        p.differentiator = lower(strtrim(get_str(T, r, col_diff)));

        % useSecondary — true if cell contains 'true','yes','1'
        sec_str = lower(strtrim(get_str(T, r, col_sec)));
        p.use_secondary = any(strcmpi(sec_str, {'true','yes','1'}));

        % plotFilter — raw string, parsed later per plot
        p.plot_filter = strtrim(get_str(T, r, col_filt));

        % Colour mode — default to manufacturer
        cm = lower(strtrim(get_str(T, r, col_col)));
        if isempty(cm) || strcmpi(cm,'none') || strcmpi(cm,'NaN')
            cm = 'manufacturer';
        end
        p.colour_mode = cm;

        % Collect non-empty y channels
        ycols = {col_y1, col_y2, col_y3, col_y4};
        ych   = {};
        for i = 1:4
            if ~isempty(ycols{i})
                v = strtrim(get_str(T, r, ycols{i}));
                if ~isempty(v) && ~strcmpi(v,'none') && ~strcmpi(v,'NaN')
                    ych{end+1} = v; %#ok
                end
            end
        end
        p.y_channels = ych;

        plots(r) = p;

        fprintf('  [%d] "%-20s"  type=%-12s  math=%-10s  colour=%-14s  sec=%-5s  y={%s}\n', ...
            r, p.name, p.type, p.math_fn, p.colour_mode, ...
            mat2str(p.use_secondary), strjoin(p.y_channels,', '));
    end
end


% ======================================================================= %
function col = find_col(var_names, candidates)
    col = '';
    for i = 1:numel(candidates)
        idx = find(strcmpi(var_names, candidates{i}), 1);
        if ~isempty(idx), col = var_names{idx}; return; end
    end
    for i = 1:numel(candidates)
        for j = 1:numel(var_names)
            if contains(lower(var_names{j}), lower(candidates{i}))
                col = var_names{j}; return;
            end
        end
    end
end

function s = get_str(T, r, col)
    if isempty(col) || ~ismember(col, T.Properties.VariableNames)
        s = ''; return;
    end
    v = T.(col)(r);
    if iscell(v),    s = strtrim(char(string(v{1}))); return; end
    if isstring(v),  s = strtrim(char(v));            return; end
    if isnumeric(v), s = '';                          return; end
    s = strtrim(char(string(v)));
end
