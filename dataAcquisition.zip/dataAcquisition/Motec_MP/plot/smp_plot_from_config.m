function figs = smp_plot_from_config(SMP, plots, cfg, driver_map, opts)
% SMP_PLOT_FROM_CONFIG  Generate all plots defined in a plot config struct.
%
% Takes a filtered SMP struct and plot config from smp_plot_config_load,
% slices laps, applies math, and renders each plot.
%
% Usage:
%   figs = smp_plot_from_config(SMP, plots, cfg)
%   figs = smp_plot_from_config(SMP, plots, cfg, driver_map)
%   figs = smp_plot_from_config(SMP, plots, cfg, driver_map, opts)
%
% Inputs:
%   SMP         - filtered SMP struct from smp_filter()
%   plots       - struct array from smp_plot_config_load()
%   cfg         - colour config from smp_colours()
%   driver_map  - (optional) struct from smp_driver_alias_load(). Pass []
%                 to skip driver colour support.
%
% Options (opts struct):
%   .min_lap_time    double   lap filter min seconds       (default: 85)
%   .max_lap_time    double   lap filter max seconds       (default: 115)
%   .n_laps_avg      double   N for N-lap average timeseries (default: 3)
%   .verbose         logical                               (default: true)
%   .fig_width       double   pixels                       (default: 1200)
%   .fig_height      double   pixels                       (default: 650)
%   .font_size       double                                (default: 11)
%   .save_path       char     folder to auto-save PNGs     (default: '')
%   .dist_channel    char     distance channel name        (default: 'Distance')
%   .dist_n_points   double   interp points for timeseries (default: 1000)
%
% Supported plot types:
%   scatter      - per-lap stat dots, sorted descending if "falling" in name
%   line         - per-lap stat connected line
%   boxplot      - distribution box per run
%   violin       - kernel density violin per run
%   histogram    - distribution histogram per run
%   timeseries   - distance-based trace: fastest lap + optional N-lap avg

    % ------------------------------------------------------------------ %
    %  Defaults
    % ------------------------------------------------------------------ %
    if nargin < 4, driver_map = []; end
    if nargin < 5 || isempty(opts), opts = struct(); end

    min_lt      = get_opt(opts, 'min_lap_time',  85);
    max_lt      = get_opt(opts, 'max_lap_time',  115);
    n_laps_avg  = get_opt(opts, 'n_laps_avg',    3);
    verbose     = get_opt(opts, 'verbose',        true);
    save_path   = get_opt(opts, 'save_path',      '');
    dist_ch     = get_opt(opts, 'dist_channel',   'Distance');
    dist_npts   = get_opt(opts, 'dist_n_points',  1000);

    SHAPES = {'o','s','^','d'};

    % ---- Normalise colour config ----
    if isfield(cfg, 'colours'), colour_cfg = cfg.colours;
    else,                       colour_cfg = cfg; end

    if verbose, fprintf('\n=== smp_plot_from_config ===\n'); end

    % ------------------------------------------------------------------ %
    %  Collect all channels needed
    % ------------------------------------------------------------------ %
    all_y = {};
    all_x = {};
    for p = 1:numel(plots)
        all_y = [all_y, plots(p).y_channels]; %#ok
        xa = plots(p).x_axis;
        if ~is_keyword(xa), all_x{end+1} = xa; end %#ok
    end
    stat_channels = unique([all_y, all_x]);

    % ------------------------------------------------------------------ %
    %  Process all runs: slice laps, compute stats
    % ------------------------------------------------------------------ %
    run_list = [];
    team_keys = fieldnames(SMP);

    for t = 1:numel(team_keys)
        tk   = team_keys{t};
        node = SMP.(tk);

        for r = 1:height(node.meta)
            ch_struct = node.channels{r};
            if isempty(ch_struct), continue; end

            % Lap slice
            lap_opts.min_lap_time = min_lt;
            lap_opts.max_lap_time = max_lt;
            lap_opts.verbose      = false;
            try
                laps = lap_slicer(ch_struct, lap_opts);
            catch ME
                if verbose, fprintf('  [WARN] %s r%d lap_slicer: %s\n', tk, r, ME.message); end
                continue;
            end
            if isempty(laps), continue; end

            % Per-lap stats
            try
                stats = lap_stats(laps, stat_channels, ...
                    struct('operations', {{'max','min','mean','var'}}));
            catch ME
                if verbose, fprintf('  [WARN] %s r%d lap_stats: %s\n', tk, r, ME.message); end
                continue;
            end

            % Store entry
            entry.driver       = strtrim(char(string(node.meta.Driver{r})));
            entry.team         = tk;
            entry.manufacturer = strtrim(char(string(node.meta.Manufacturer{r})));
            entry.session      = strtrim(char(string(node.meta.Session{r})));

            % Resolve authoritative car number from driver alias table.
            % Falls back to MoTeC metadata CarNumber if no match found.
            entry.car = resolve_car_number(entry.driver, driver_map, ...
                strtrim(char(string(node.meta.CarNumber{r}))));
            entry.stats        = stats;
            entry.laps         = laps;    % keep raw laps for timeseries
            entry.n_laps       = numel(laps);

            if isempty(run_list), run_list = entry;
            else,                 run_list(end+1) = entry; end %#ok

            if verbose
                fprintf('  %-6s | %-22s | %-12s | %-10s | %d laps\n', ...
                    entry.car, entry.driver, entry.manufacturer, entry.session, entry.n_laps);
            end
        end
    end

    if isempty(run_list)
        warning('smp_plot_from_config: no valid runs found.');
        figs = {};
        return;
    end
    fprintf('\n%d runs ready for plotting.\n\n', numel(run_list));

    % ------------------------------------------------------------------ %
    %  Generate each plot
    % ------------------------------------------------------------------ %
    figs = cell(numel(plots), 1);

    for p = 1:numel(plots)
        pd = plots(p);
        if verbose
            fprintf('--- Plot %d: "%s"  [%s / %s / colour=%s]\n', ...
                p, pd.name, pd.type, pd.math_fn, pd.colour_mode);
        end

        try
            % ---- Apply per-plot filter ----
            if isfield(pd, 'plot_filter') && ~isempty(pd.plot_filter)
                filter_groups  = smp_parse_plot_filter(pd.plot_filter);
                plot_run_list  = smp_apply_plot_filter(run_list, filter_groups);
            else
                plot_run_list  = run_list;
            end

            if isempty(plot_run_list)
                warning('smp_plot_from_config: plot "%s" — no runs after filter.', pd.name);
                continue;
            end

            switch pd.type
                case 'scatter'
                    figs{p} = make_scatter(plot_run_list, pd, colour_cfg, driver_map, opts, SHAPES);
                case 'line'
                    figs{p} = make_line(plot_run_list, pd, colour_cfg, driver_map, opts, SHAPES);
                case 'boxplot'
                    figs{p} = make_boxplot(plot_run_list, pd, colour_cfg, driver_map, opts);
                case 'violin'
                    figs{p} = make_violin(plot_run_list, pd, colour_cfg, driver_map, opts);
                case 'histogram'
                    figs{p} = make_histogram(plot_run_list, pd, colour_cfg, driver_map, opts);
                case 'timeseries'
                    figs{p} = make_timeseries(plot_run_list, pd, colour_cfg, driver_map, opts, ...
                                              dist_ch, dist_npts, n_laps_avg);
                otherwise
                    warning('smp_plot_from_config: plot type "%s" not supported.', pd.type);
            end
        catch ME
            warning('smp_plot_from_config: plot "%s" failed: %s', pd.name, ME.message);
        end

        % Save
        if ~isempty(save_path) && ~isempty(figs{p})
            safe = regexprep(pd.name, '[^a-zA-Z0-9_\- ]', '');
            safe = strrep(strtrim(safe), ' ', '_');
            exportgraphics(figs{p}, fullfile(save_path, [safe '.png']), 'Resolution', 150);
        end
    end
end


% ======================================================================= %
%  COLOUR HELPER
% ======================================================================= %
function col = resolve_colour(entry, colour_mode, colour_cfg, driver_map)
    switch lower(colour_mode)
        case 'driver'
            if ~isempty(driver_map) && isstruct(driver_map)
                col = local_driver_colour(driver_map, entry.driver);
            else
                col = get_colour(colour_cfg, entry.driver, 'driver');
            end
        case 'team'
            col = get_colour(colour_cfg, entry.team, 'manufacturer');
        otherwise   % manufacturer
            col = get_colour(colour_cfg, entry.manufacturer, 'manufacturer');
    end
end


% ======================================================================= %
%  FIGURE FACTORY
% ======================================================================= %
function [fig, ax_left, ax_right] = new_fig(pd, opts)
    fw = get_opt(opts, 'fig_width',  1200);
    fh = get_opt(opts, 'fig_height', 650);
    fs = get_opt(opts, 'font_size',  11);

    fig = figure('Visible','off','Color','white','Position',[100 100 fw fh]);
    ax_left  = axes(fig);
    ax_right = [];   % only populated if use_secondary=true

    hold(ax_left,'on'); box(ax_left,'on'); grid(ax_left,'on');
    set(ax_left,'FontSize',fs,'FontName','Arial', ...
           'GridAlpha',0.25,'GridLineStyle','--','GridColor',[0.7 0.7 0.7]);
    ax_left.Color  = [0.97 0.97 0.97];
    fig.Color = 'white';
    ax_left.XColor = [0.2 0.2 0.2];
    ax_left.YColor = [0.2 0.2 0.2];

    % Secondary axis (right) — only when requested
    if isfield(pd,'use_secondary') && pd.use_secondary && numel(pd.y_channels) >= 2
        yyaxis(ax_left, 'right');
        ax_right = ax_left;   % yyaxis shares the same axes object
        ax_left.YAxis(2).Color = [0.2 0.2 0.2];
        yyaxis(ax_left, 'left');
    end

    fs1 = fs + 1;
    title(ax_left, pd.name, 'FontSize', fs1, 'FontWeight', 'bold', 'Interpreter', 'none');
end

function apply_legend(ax, handles, labels, opts)
    valid = isgraphics(handles);
    if ~any(valid), return; end
    fs = get_opt(opts, 'font_size', 11);
    legend(ax, handles(valid), labels(valid), ...
        'Location','best','FontSize',fs-1,'Box','off','Interpreter','none');
end


% ======================================================================= %
%  SCATTER
% ======================================================================= %
function fig = make_scatter(run_list, pd, colour_cfg, driver_map, opts, SHAPES)
    [fig, ax] = new_fig(pd, opts);
    fs = get_opt(opts, 'font_size', 11);
    use_secondary = isfield(pd,'use_secondary') && pd.use_secondary && numel(pd.y_channels) >= 2;
    use_shapes = strcmpi(pd.differentiator, 'shapes');
    is_falling = contains(lower(pd.name),'falling') || contains(lower(pd.x_axis),'falling');

    leg_h = []; leg_l = {};
    x_lbl = 'Lap Number';

    for r = 1:numel(run_list)
        entry = run_list(r);
        col   = resolve_colour(entry, pd.colour_mode, colour_cfg, driver_map);

        for yi = 1:numel(pd.y_channels)
            y_ch    = pd.y_channels{yi};
            y_field = sanitise_fn(y_ch);
            if ~isfield(entry.stats, y_field), continue; end

            % Switch to secondary axis for yAxis2+
            if use_secondary && yi == 2
                yyaxis(ax, 'right');
                ylabel(ax, pd.y_channels{yi}, 'FontSize', fs, 'Interpreter','none');
            elseif use_secondary && yi == 1
                yyaxis(ax, 'left');
                ylabel(ax, pd.y_channels{1}, 'FontSize', fs, 'Interpreter','none');
            end

            y_vals   = local_apply_math(entry.stats.(y_field), pd.math_fn);
            lap_nums = entry.stats.(y_field).lap_numbers;
            valid    = isfinite(y_vals);
            y_vals   = y_vals(valid);  lap_nums = lap_nums(valid);
            if isempty(y_vals), continue; end

            if is_falling
                [y_vals, ~] = sort(y_vals, 'descend');
                x_vals = 1:numel(y_vals);  x_lbl = 'Rank';
            elseif is_keyword_lap(pd.x_axis)
                x_vals = lap_nums;  x_lbl = 'Lap Number';
            else
                x_field = sanitise_fn(pd.x_axis);
                if isfield(entry.stats, x_field)
                    xv = local_apply_math(entry.stats.(x_field), pd.math_fn);
                    x_vals = xv(valid);  x_lbl = pd.x_axis;
                else
                    x_vals = lap_nums;  x_lbl = 'Lap Number';
                end
            end

            marker = 'o';
            if use_shapes && yi <= numel(SHAPES), marker = SHAPES{yi}; end

            h = scatter(ax, x_vals, y_vals, 40, col, marker, 'filled', ...
                'MarkerEdgeColor', col*0.7, 'MarkerFaceAlpha', 0.8);

            leg_h(end+1) = h;                           %#ok
            leg_l{end+1} = build_label(entry, pd, yi);  %#ok
        end
    end

    if use_secondary, yyaxis(ax, 'left'); end
    xlabel(ax, x_lbl, 'FontSize', fs, 'Interpreter', 'none');
    if ~use_secondary
        ylabel(ax, strjoin(pd.y_channels,' / '), 'FontSize', fs, 'Interpreter','none');
    end
    apply_legend(ax, leg_h, leg_l, opts);
    if use_shapes && numel(pd.y_channels) > 1
        add_shape_key(fig, pd.y_channels, SHAPES, fs);
    end
end


% ======================================================================= %
%  LINE
% ======================================================================= %
function fig = make_line(run_list, pd, colour_cfg, driver_map, opts, SHAPES)
    [fig, ax] = new_fig(pd, opts);
    fs = get_opt(opts, 'font_size', 11);
    use_secondary = isfield(pd,'use_secondary') && pd.use_secondary && numel(pd.y_channels) >= 2;
    use_shapes = strcmpi(pd.differentiator, 'shapes');

    leg_h = []; leg_l = {};
    x_lbl = 'Lap Number';

    for r = 1:numel(run_list)
        entry = run_list(r);
        col   = resolve_colour(entry, pd.colour_mode, colour_cfg, driver_map);

        for yi = 1:numel(pd.y_channels)
            y_ch    = pd.y_channels{yi};
            y_field = sanitise_fn(y_ch);
            if ~isfield(entry.stats, y_field), continue; end

            if use_secondary && yi == 2
                yyaxis(ax, 'right');
                ylabel(ax, pd.y_channels{yi}, 'FontSize', fs, 'Interpreter','none');
            elseif use_secondary && yi == 1
                yyaxis(ax, 'left');
                ylabel(ax, pd.y_channels{1}, 'FontSize', fs, 'Interpreter','none');
            end

            y_vals   = local_apply_math(entry.stats.(y_field), pd.math_fn);
            lap_nums = entry.stats.(y_field).lap_numbers;
            valid    = isfinite(y_vals);
            y_vals   = y_vals(valid);  lap_nums = lap_nums(valid);
            if isempty(y_vals), continue; end

            if is_keyword_lap(pd.x_axis)
                x_vals = lap_nums;  x_lbl = 'Lap Number';
            else
                x_field = sanitise_fn(pd.x_axis);
                if isfield(entry.stats, x_field)
                    xv = local_apply_math(entry.stats.(x_field), pd.math_fn);
                    x_vals = xv(valid);  x_lbl = pd.x_axis;
                else
                    x_vals = lap_nums;  x_lbl = 'Lap Number';
                end
            end

            marker = 'none';
            if use_shapes && yi <= numel(SHAPES), marker = SHAPES{yi}; end

            h = plot(ax, x_vals, y_vals, '-', ...
                'Color', col, 'LineWidth', 1.8, 'Marker', marker, 'MarkerSize', 5);

            leg_h(end+1) = h;                           %#ok
            leg_l{end+1} = build_label(entry, pd, yi);  %#ok
        end
    end

    if use_secondary, yyaxis(ax, 'left'); end
    xlabel(ax, x_lbl, 'FontSize', fs, 'Interpreter','none');
    if ~use_secondary
        ylabel(ax, strjoin(pd.y_channels,' / '), 'FontSize', fs, 'Interpreter','none');
    end
    apply_legend(ax, leg_h, leg_l, opts);
end


% ======================================================================= %
%  BOXPLOT
% ======================================================================= %
function fig = make_boxplot(run_list, pd, colour_cfg, driver_map, opts)
    [fig, ax] = new_fig(pd, opts);

    all_vals = []; all_grp = []; grp_labels = {}; colours = [];
    gi = 0;

    for r = 1:numel(run_list)
        entry = run_list(r);
        col   = resolve_colour(entry, pd.colour_mode, colour_cfg, driver_map);

        for yi = 1:numel(pd.y_channels)
            y_field = sanitise_fn(pd.y_channels{yi});
            if ~isfield(entry.stats, y_field), continue; end

            vals = get_dist_vals(entry, y_field, pd.math_fn);
            if isempty(vals), continue; end

            gi = gi + 1;
            all_vals  = [all_vals;  vals(:)];           %#ok
            all_grp   = [all_grp;   repmat(gi, numel(vals), 1)]; %#ok
            grp_labels{gi} = build_label(entry, pd, yi); %#ok
            colours(gi,:) = col;                        %#ok
        end
    end

    if isempty(all_vals), return; end

    bp = boxplot(ax, all_vals, all_grp, 'Labels', grp_labels, 'Widths', 0.6, 'Symbol', '+');
    colour_boxplot(bp, colours);
    ax.XTickLabelRotation = 30;
    xlabel(ax, '', 'Interpreter', 'none');
end


% ======================================================================= %
%  VIOLIN
% ======================================================================= %
function fig = make_violin(run_list, pd, colour_cfg, driver_map, opts)
    [fig, ax] = new_fig(pd, opts);
    fs = get_opt(opts, 'font_size', 11);

    gi = 0; tick_pos = []; tick_labels = {};

    for r = 1:numel(run_list)
        entry = run_list(r);
        col   = resolve_colour(entry, pd.colour_mode, colour_cfg, driver_map);

        for yi = 1:numel(pd.y_channels)
            y_field = sanitise_fn(pd.y_channels{yi});
            if ~isfield(entry.stats, y_field), continue; end

            vals = get_dist_vals(entry, y_field, pd.math_fn);
            if numel(vals) < 3, continue; end

            gi = gi + 1;
            [f, xi] = ksdensity(vals);
            f = f / max(f) * 0.4;
            fill(ax, [gi+f, fliplr(gi-f)], [xi, fliplr(xi)], col, ...
                'FaceAlpha',0.65,'EdgeColor',col*0.75,'LineWidth',0.8);
            plot(ax, [gi-0.15 gi+0.15], [median(vals) median(vals)], ...
                '-','Color',col*0.5,'LineWidth',2);
            plot(ax, [gi gi], [prctile(vals,25) prctile(vals,75)], ...
                '-','Color',col*0.5,'LineWidth',3);

            tick_pos(end+1)    = gi;          %#ok
            tick_labels{end+1} = build_label(entry, pd, yi); %#ok
        end
    end

    set(ax,'XTick',tick_pos,'XTickLabel',tick_labels);
    ax.XTickLabelRotation = 30;
    xlim(ax,[0.5, gi+0.5]);
end


% ======================================================================= %
%  HISTOGRAM
% ======================================================================= %
function fig = make_histogram(run_list, pd, colour_cfg, driver_map, opts)
    [fig, ax] = new_fig(pd, opts);
    fs = get_opt(opts, 'font_size', 11);

    leg_h = []; leg_l = {};

    for r = 1:numel(run_list)
        entry = run_list(r);
        col   = resolve_colour(entry, pd.colour_mode, colour_cfg, driver_map);

        for yi = 1:numel(pd.y_channels)
            y_field = sanitise_fn(pd.y_channels{yi});
            if ~isfield(entry.stats, y_field), continue; end

            vals = get_dist_vals(entry, y_field, pd.math_fn);
            if isempty(vals), continue; end

            h = histogram(ax, vals, 'FaceColor', col, 'EdgeColor', col*0.7, ...
                'FaceAlpha', 0.5, 'Normalization', 'probability');

            leg_h(end+1) = h;              %#ok
            leg_l{end+1} = build_label(entry, pd, yi); %#ok
        end
    end

    xlabel(ax, strjoin(pd.y_channels,' / '), 'FontSize', fs, 'Interpreter','none');
    ylabel(ax, 'Probability', 'FontSize', fs);
    apply_legend(ax, leg_h, leg_l, opts);
end


% ======================================================================= %
%  TIMESERIES  (distance-based, fastest lap + N-lap average)
% ======================================================================= %
function fig = make_timeseries(run_list, pd, colour_cfg, driver_map, opts, ...
                                dist_ch, dist_npts, n_laps_avg)
    [fig, ax] = new_fig(pd, opts);
    fs  = get_opt(opts, 'font_size', 11);
    lw  = 2.0;
    lwa = 0.8;

    leg_h = []; leg_l = {};

    for r = 1:numel(run_list)
        entry = run_list(r);
        col   = resolve_colour(entry, pd.colour_mode, colour_cfg, driver_map);
        laps  = entry.laps;

        lap_times  = [laps.lap_time];
        [~, best]  = min(lap_times);

        dist_field = find_ch_field(laps(best).channels, dist_ch);
        if isempty(dist_field)
            fprintf('  [WARN] Distance channel "%s" not found for %s\n', dist_ch, entry.driver);
            continue;
        end
        d_best = laps(best).channels.(dist_field).data;
        d_grid = linspace(min(d_best), max(d_best), dist_npts)';

        for yi = 1:numel(pd.y_channels)
            y_ch    = pd.y_channels{yi};
            y_field = find_ch_field(laps(best).channels, y_ch);
            if isempty(y_field)
                fprintf('  [WARN] Channel "%s" not found for %s\n', y_ch, entry.driver);
                continue;
            end

            % ---- Fastest lap (bold solid) ----
            % Interpolate y channel onto common distance grid via time alignment
            y_best   = laps(best).channels.(y_field).data;
            t_dist   = laps(best).channels.(dist_field).time;
            t_ych    = laps(best).channels.(y_field).time;
            % Resample distance onto y channel time axis, then interp y vs distance
            d_on_y   = interp1(t_dist, d_best, t_ych, 'linear', NaN);
            valid_d  = isfinite(d_on_y) & isfinite(y_best);
            if sum(valid_d) < 2, continue; end
            y_interp = interp1(d_on_y(valid_d), y_best(valid_d), d_grid, 'linear', NaN);

            h_best = plot(ax, d_grid, y_interp, '-', 'Color', col, 'LineWidth', lw);
            leg_h(end+1) = h_best; %#ok
            leg_l{end+1} = sprintf('%s  [fastest]', entry.driver); %#ok

            % ---- N-lap average + individual laps + P25/P75 band ----
            if n_laps_avg > 1 && numel(laps) >= n_laps_avg
                [~, sorted_idx] = sort(lap_times, 'ascend');
                avg_idx = sorted_idx(1:n_laps_avg);

                lap_mat = NaN(dist_npts, n_laps_avg);
                for k = 1:n_laps_avg
                    li  = avg_idx(k);
                    d_k    = laps(li).channels.(dist_field).data;
                    y_k    = laps(li).channels.(y_field).data;
                    t_dk   = laps(li).channels.(dist_field).time;
                    t_yk   = laps(li).channels.(y_field).time;
                    d_on_yk = interp1(t_dk, d_k, t_yk, 'linear', NaN);
                    valid_dk = isfinite(d_on_yk) & isfinite(y_k);

                    % Individual lap (transparent)
                    if sum(valid_dk) < 2
                        y_k_interp = NaN(dist_npts, 1);
                    else
                        y_k_interp = interp1(d_on_yk(valid_dk), y_k(valid_dk), d_grid, 'linear', NaN);
                    end
                    plot(ax, d_grid, y_k_interp, '-', ...
                        'Color', [col, 0.25], 'LineWidth', lwa);
                    lap_mat(:,k) = y_k_interp;
                end

                % Average trace (bold dashed)
                y_avg = mean(lap_mat, 2, 'omitnan');
                h_avg = plot(ax, d_grid, y_avg, '--', 'Color', col, 'LineWidth', lw);
                leg_h(end+1) = h_avg; %#ok
                leg_l{end+1} = sprintf('%s  [%d-lap avg]', entry.driver, n_laps_avg); %#ok

                % P25/P75 shaded band
                y_p25 = prctile(lap_mat, 25, 2);
                y_p75 = prctile(lap_mat, 75, 2);
                valid_band = ~isnan(y_p25) & ~isnan(y_p75);
                if any(valid_band)
                    xb = [d_grid(valid_band); flipud(d_grid(valid_band))];
                    yb = [y_p25(valid_band);  flipud(y_p75(valid_band))];
                    fill(ax, xb, yb, col, ...
                        'FaceAlpha', 0.15, 'EdgeColor', 'none');
                end
            end
        end
    end

    xlabel(ax, 'Distance (m)', 'FontSize', fs, 'Interpreter','none');
    ylabel(ax, strjoin(pd.y_channels,' / '), 'FontSize', fs, 'Interpreter','none');
    apply_legend(ax, leg_h, leg_l, opts);
end


% ======================================================================= %
%  DISTRIBUTION DATA HELPER
%  Returns either per-lap stat values or within-lap raw samples
%  depending on whether mathFunction is an aggregating or raw operation.
% ======================================================================= %
function vals = get_dist_vals(entry, y_field, math_fn)
% For box/violin/histogram:
%   aggregating functions (max/min/mean/var) → use per-lap stat vector
%   derivative/integral                      → pool raw samples across laps

    agg_fns = {'max','min','mean','variance','var'};

    if ismember(lower(math_fn), agg_fns)
        vals = local_apply_math(entry.stats.(y_field), math_fn);
        vals = vals(isfinite(vals));
    else
        % Pool raw samples from all laps, apply function per lap then pool
        vals = [];
        for k = 1:numel(entry.laps)
            ch_field = find_ch_field(entry.laps(k).channels, y_field);
            if isempty(ch_field), continue; end
            ch = entry.laps(k).channels.(ch_field);
            t  = ch.time;
            dt = median(diff(t));
            if isnan(dt) || dt <= 0, dt = 1; end
            v = local_apply_math_sample(ch.data, math_fn, dt);
            vals = [vals; v(:)]; %#ok
        end
        vals = vals(isfinite(vals));
    end
end


% ======================================================================= %
%  BOXPLOT COLOURING
% ======================================================================= %
function colour_boxplot(bp, colours)
    boxes = findobj(bp,'Tag','Box');
    meds  = findobj(bp,'Tag','Median');
    n = numel(boxes);
    for i = 1:n
        j = n - i + 1;
        if j > size(colours,1), continue; end
        col = colours(j,:);
        patch(get(boxes(i),'XData'), get(boxes(i),'YData'), col, ...
            'FaceAlpha',0.75,'EdgeColor',col*0.7,'LineWidth',1.2);
        set(meds(i),'Color',col*0.5,'LineWidth',2);
    end
end


% ======================================================================= %
%  SHAPE KEY ANNOTATION
% ======================================================================= %
function add_shape_key(fig, y_channels, SHAPES, fs)
    names = {'● Circle','■ Square','▲ Triangle','◆ Diamond'};
    lines = {'Shapes:'};
    for i = 1:min(numel(y_channels), numel(SHAPES))
        lines{end+1} = sprintf('  %s = %s', names{i}, y_channels{i}); %#ok
    end
    annotation(fig,'textbox','Units','normalized', ...
        'Position',[0.01 0.01 0.01 0.01], ...
        'String',lines,'FontSize',fs-2,'FontName','Arial', ...
        'EdgeColor',[0.7 0.7 0.7],'BackgroundColor','white', ...
        'FitBoxToText','on','Interpreter','none');
end


% ======================================================================= %
%  LABEL BUILDER
% ======================================================================= %
function lbl = build_label(entry, pd, yi)
    lbl = entry.driver;
    if numel(pd.y_channels) > 1
        lbl = sprintf('%s  [%s]', entry.driver, pd.y_channels{yi});
    end
end


% ======================================================================= %
%  UTILITIES
% ======================================================================= %
function tf = is_keyword(str)
    tf = is_keyword_lap(str) || contains(lower(str),'falling');
end

function tf = is_keyword_lap(str)
    tf = any(strcmpi(str, {'Lap Number','Lap_Number','lap'}));
end

function name = sanitise_fn(ch)
    name = regexprep(strtrim(ch), '[^a-zA-Z0-9]', '_');
    if ~isempty(name) && isstrprop(name(1),'digit')
        name = ['ch_', name];
    end
end

function field = find_ch_field(channels, name)
    ch_names = fieldnames(channels);
    if isfield(channels, name), field = name; return; end
    san = regexprep(name, '[^a-zA-Z0-9_]', '_');
    if isfield(channels, san), field = san; return; end
    for i = 1:numel(ch_names)
        if strcmpi(ch_names{i}, name) || strcmpi(ch_names{i}, san)
            field = ch_names{i}; return;
        end
    end
    field = '';
end

function v = get_opt(s, f, default)
    if isfield(s,f) && ~isempty(s.(f)), v = s.(f);
    else,                                v = default; end
end


% ======================================================================= %
%  INLINE MATH HELPERS  (no external file dependency)
% ======================================================================= %
function vals = local_apply_math(stat, math_fn)
% Apply math function to a lap_stats result struct.
    switch lower(math_fn)
        case 'max',                vals = stat.max;
        case 'min',                vals = stat.min;
        case {'mean','average'},   vals = stat.mean;
        case {'variance','var'},   vals = stat.var;
        case {'derivative','diff'},vals = gradient(stat.max);
        case {'integral','int'},   vals = cumtrapz(stat.max);
        otherwise
            warning('local_apply_math: unknown function "%s" — using max.', math_fn);
            vals = stat.max;
    end
end

function result = local_apply_math_sample(data, math_fn, dt)
% Apply math function to a raw sample vector.
    if nargin < 3, dt = 1; end
    d = data(:);
    d_fin = d(isfinite(d));
    if isempty(d_fin), result = NaN; return; end
    switch lower(math_fn)
        case 'max',                result = max(d_fin);
        case 'min',                result = min(d_fin);
        case {'mean','average'},   result = mean(d_fin);
        case {'variance','var'},   result = var(d_fin);
        case {'derivative','diff'},result = gradient(d, dt);
        case {'integral','int'},   result = cumtrapz(d) * dt;
        otherwise
            warning('local_apply_math_sample: unknown "%s".', math_fn);
            result = NaN;
    end
end

function col = local_driver_colour(driver_map, name)
% Inline driver colour lookup — no external file dependency.
    col = [0.55 0.55 0.55];   % fallback grey
    if isempty(driver_map) || ~isstruct(driver_map), return; end
    name_lower = lower(strtrim(name));
    keys = fieldnames(driver_map);
    for k = 1:numel(keys)
        entry = driver_map.(keys{k});
        if any(strcmp(entry.aliases, name_lower))
            col = entry.colour;
            return;
        end
    end
end


% ======================================================================= %
function car = resolve_car_number(driver_name, driver_map, fallback)
% Look up the authoritative car number (NUM) from the driver alias table.
% Matches driver_name against all aliases in the map.
% Returns fallback (from MoTeC meta) if no match found.

    car = fallback;
    if isempty(driver_map) || ~isstruct(driver_map), return; end

    name_lower = lower(strtrim(driver_name));
    keys = fieldnames(driver_map);
    for k = 1:numel(keys)
        entry = driver_map.(keys{k});
        if any(strcmp(entry.aliases, name_lower))
            if isfield(entry, 'num') && ~isempty(entry.num)
                car = entry.num;
            end
            return;
        end
    end
end