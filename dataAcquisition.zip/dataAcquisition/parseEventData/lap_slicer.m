function laps = lap_slicer(session, varargin)
% LAP_SLICER  Slice a MoTeC session into per-lap structs using the
%             Running Lap Time channel as both the lap boundary detector
%             and the x-axis for every sliced channel.
%
% Running Lap Time resets to 0 (or near-0) at each lap boundary, making
% it the most reliable lap detector — no separate Lap_Number channel needed.
%
% Usage:
%   laps = lap_slicer(session)
%   laps = lap_slicer(session, 'lap_time_channel', 'Running_Lap_Time')
%   laps = lap_slicer(session, 'min_lap_time', 30, 'exclude_laps', [1])
%
% Parameters (Name-Value):
%   'lap_time_channel'   Channel name for running lap time
%                        (default: auto-detected, see LAP_TIME_CANDIDATES)
%   'lap_time_units'     'auto' detects from channel units field.
%                        Override with 'ms' or 's' if auto-detection fails.
%                        (default: 'auto')
%   'reset_threshold'    A drop in running lap time by more than this value
%                        (in seconds, after unit conversion) is treated as a
%                        lap boundary. (default: 5)
%   'min_lap_time'       Minimum valid lap duration in seconds. (default: 20)
%   'max_lap_time'       Maximum valid lap duration in seconds. (default: 600)
%   'lap_range'          [first last] — only keep laps in this range, e.g. [2 20]
%                        (default: all)
%   'exclude_laps'       Lap numbers to exclude, e.g. [1 15]. (default: [])
%   'verbose'            Print lap summary. (default: true)
%
% Returns:
%   laps    Struct array, one element per valid lap:
%
%   laps(k).lap_number       Integer lap index (1-based, after filtering)
%   laps(k).lap_time         Lap duration in seconds
%   laps(k).t_start          Session time (file x-axis) at lap start
%   laps(k).t_end            Session time at lap end
%   laps(k).channels         Struct of sliced channels (same fields as session)
%
%   Each channel within laps(k).channels has:
%     .data          Sliced data values
%     .lap_time      Running lap time in seconds (x-axis, starts at 0)
%     .time_abs      Absolute session time (original file x-axis)
%     .units         Original units string
%     .sample_rate   Original sample rate
%     .raw_name      Original channel name string

    % ------------------------------------------------------------------
    %  Parse name-value parameters
    % ------------------------------------------------------------------
    p = inputParser();
    p.addParameter('lap_time_channel',  '');
    p.addParameter('lap_time_units',    'auto');
    p.addParameter('reset_threshold',   5);
    p.addParameter('min_lap_time',      20);
    p.addParameter('max_lap_time',      600);
    p.addParameter('lap_range',         []);
    p.addParameter('exclude_laps',      []);
    p.addParameter('verbose',           true);
    p.parse(varargin{:});
    o = p.Results;

    % Candidate channel names for running lap time (tried in order)
    LAP_TIME_CANDIDATES = {
        'Running_Lap_Time', 'Run_Lap_Time', 'Lap_Time', ...
        'Running_Lap_Timer', 'LapTime', 'Lap_Timer'
    };

    % ------------------------------------------------------------------
    %  Find the running lap time channel
    % ------------------------------------------------------------------
    ch_names  = fieldnames(session);

    if ~isempty(o.lap_time_channel)
        rlt_field = find_channel(session, o.lap_time_channel, ch_names);
        if isempty(rlt_field)
            error('lap_slicer: specified lap_time_channel "%s" not found.', o.lap_time_channel);
        end
    else
        rlt_field = '';
        for i = 1:numel(LAP_TIME_CANDIDATES)
            rlt_field = find_channel(session, LAP_TIME_CANDIDATES{i}, ch_names);
            if ~isempty(rlt_field), break; end
        end
        if isempty(rlt_field)
            error(['lap_slicer: could not auto-detect running lap time channel.\n' ...
                   'Tried: %s\nAvailable: %s\n' ...
                   'Set ''lap_time_channel'' explicitly.'], ...
                   strjoin(LAP_TIME_CANDIDATES, ', '), strjoin(ch_names, ', '));
        end
    end

    rlt_ch   = session.(rlt_field);
    rlt_data = rlt_ch.data;       % raw values
    rlt_time = rlt_ch.time;       % file x-axis (sample index / Hz)

    % ------------------------------------------------------------------
    %  Resolve units — convert to seconds if needed
    % ------------------------------------------------------------------
    units_str = lower(strtrim(rlt_ch.units));

    if strcmp(o.lap_time_units, 'auto')
        if contains(units_str, 'ms') || contains(units_str, 'millisecond')
            time_scale = 1/1000;
            resolved_units = 'ms → s';
        elseif contains(units_str, 'min')
            time_scale = 60;
            resolved_units = 'min → s';
        else
            % Assume seconds — check magnitude as a sanity guard
            % A lap time in seconds should be < 600; if raw values look like
            % milliseconds (e.g. typical value > 5000) scale automatically.
            typical_val = median(rlt_data(rlt_data > 0), 'omitnan');
            if ~isempty(typical_val) && typical_val > 1000
                time_scale = 1/1000;
                resolved_units = 'auto-detected ms → s';
            else
                time_scale = 1;
                resolved_units = 's';
            end
        end
    elseif strcmp(o.lap_time_units, 'ms')
        time_scale = 1/1000;
        resolved_units = 'ms → s';
    else
        time_scale = 1;
        resolved_units = 's';
    end

    rlt_s = rlt_data * time_scale;   % running lap time in seconds

    if o.verbose
        fprintf('\n=== Lap Slicer ===\n');
        fprintf('Lap time channel : %s  (units: %s)\n', rlt_field, resolved_units);
    end

    % ------------------------------------------------------------------
    %  Detect lap boundaries — drops in running lap time
    %  A reset is where rlt_s drops by more than reset_threshold seconds.
    % ------------------------------------------------------------------
    drlt       = diff(rlt_s);
    reset_idx  = find(drlt < -o.reset_threshold);   % sample index just before reset

    % Boundary sample indices into rlt_time:
    % lap k starts at reset_idx(k)+1, ends at reset_idx(k+1)
    starts = [1;            reset_idx + 1];
    ends   = [reset_idx;    numel(rlt_s)];

    n_raw = numel(starts);

    % ------------------------------------------------------------------
    %  Build raw lap list with durations
    % ------------------------------------------------------------------
    raw_laps = struct('idx', cell(n_raw,1), 't_start', [], 't_end', [], 'duration', []);
    for k = 1:n_raw
        raw_laps(k).idx     = k;
        raw_laps(k).t_start = rlt_time(starts(k));
        raw_laps(k).t_end   = rlt_time(ends(k));
        raw_laps(k).duration = rlt_s(ends(k)) - rlt_s(starts(k));
        % For resets the duration is the max rlt_s value in this segment
        seg = rlt_s(starts(k):ends(k));
        raw_laps(k).duration = max(seg) - min(seg);
    end

    % ------------------------------------------------------------------
    %  Filter laps
    % ------------------------------------------------------------------
    valid = true(n_raw, 1);

    % Duration filter
    dur = [raw_laps.duration]';
    valid = valid & (dur >= o.min_lap_time) & (dur <= o.max_lap_time);

    % Range filter (applied to sequential index after duration filter)
    % We renumber after duration filter then apply range/exclude
    valid_idx = find(valid);

    if ~isempty(o.lap_range)
        keep = valid_idx(valid_idx >= o.lap_range(1) & valid_idx <= o.lap_range(2));
        valid(:) = false;
        valid(keep) = true;
    end

    if ~isempty(o.exclude_laps)
        valid_idx2 = find(valid);
        for ex = o.exclude_laps(:)'
            if ex >= 1 && ex <= numel(valid_idx2)
                valid(valid_idx2(ex)) = false;
            end
        end
    end

    valid_idx  = find(valid);
    n_valid    = numel(valid_idx);

    if o.verbose
        fprintf('Raw segments detected : %d\n', n_raw);
        fprintf('Valid laps after filter: %d\n', n_valid);
        fprintf('%-6s  %-10s  %-10s  %-10s\n', 'Lap', 't_start(s)', 't_end(s)', 'Duration(s)');
        fprintf('%s\n', repmat('-', 1, 42));
    end

    % ------------------------------------------------------------------
    %  Slice all channels for each valid lap
    % ------------------------------------------------------------------
    laps = struct( ...
        'lap_number', cell(1, n_valid), ...
        'lap_time',   cell(1, n_valid), ...
        't_start',    cell(1, n_valid), ...
        't_end',      cell(1, n_valid), ...
        'channels',   cell(1, n_valid));

    for k = 1:n_valid
        raw_k = raw_laps(valid_idx(k));
        t_s   = raw_k.t_start;
        t_e   = raw_k.t_end;

        laps(k).lap_number = k;
        laps(k).lap_time   = raw_k.duration;
        laps(k).t_start    = t_s;
        laps(k).t_end      = t_e;
        laps(k).channels   = struct();

        % Build the running lap time x-axis for this lap using the RLT channel
        rlt_mask     = rlt_time >= t_s & rlt_time <= t_e;
        rlt_lap_time = rlt_s(rlt_mask);    % seconds, resets to ~0 at lap start

        for c = 1:numel(ch_names)
            fn = ch_names{c};
            ch = session.(fn);
            t  = ch.time;

            % Slice by session time window
            msk = t >= t_s & t <= t_e;

            sliced            = ch;
            sliced.data       = ch.data(msk);
            sliced.time_abs   = t(msk);

            % Map this channel's samples onto running lap time via interp1
            % (channels have different sample rates so we interpolate RLT)
            if numel(rlt_time(rlt_mask)) >= 2 && numel(t(msk)) >= 1
                sliced.lap_time = interp1( ...
                    rlt_time(rlt_mask), rlt_lap_time, t(msk), 'linear', 'extrap');
                sliced.lap_time = max(sliced.lap_time, 0);   % clamp negatives at boundary
            else
                sliced.lap_time = t(msk) - t_s;   % fallback: relative file time
            end

            laps(k).channels.(fn) = sliced;
        end

        if o.verbose
            fprintf('  Lap %-3d  t_start=%8.2f  t_end=%8.2f  dur=%6.2f s\n', ...
                k, t_s, t_e, raw_k.duration);
        end
    end

    if o.verbose
        fprintf('\nSliced %d valid laps.\n\n', n_valid);
    end
end


% ======================================================================= %
function field = find_channel(session, name, ch_names)
    if isfield(session, name),  field = name;  return;  end
    san = regexprep(name, '[^a-zA-Z0-9_]', '_');
    san = regexprep(san, '_+', '_');
    if isfield(session, san),   field = san;   return;  end
    for i = 1:numel(ch_names)
        if strcmpi(ch_names{i}, name) || strcmpi(ch_names{i}, san)
            field = ch_names{i};
            return;
        end
    end
    field = '';
end