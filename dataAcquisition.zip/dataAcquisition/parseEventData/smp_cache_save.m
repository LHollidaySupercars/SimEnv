function smp_cache_save(top_level_dir, cache)
% SMP_CACHE_SAVE  Save the updated cache manifest to disk.

    cache_path = fullfile(top_level_dir, 'smp_cache.mat');
    save(cache_path, 'cache', '-v7.3');
    fprintf('Cache saved: %s  (%d entries)\n', cache_path, height(cache.manifest));
end
