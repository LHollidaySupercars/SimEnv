function cache = smp_cache_load(top_level_dir)
% SMP_CACHE_LOAD  Load the SMP file cache manifest from disk.
% If no cache exists yet, returns an empty cache struct ready to be populated.
% Cache file lives at: <top_level_dir>\smp_cache.mat

    cache_path = fullfile(top_level_dir, 'smp_cache.mat');

    if exist(cache_path, 'file')
        fprintf('Loading cache: %s\n', cache_path);
        loaded = load(cache_path, 'cache');
        cache  = loaded.cache;
        fprintf('  Cache has %d entries.\n', height(cache.manifest));
    else
        fprintf('No cache found — starting fresh.\n');
        cache = smp_cache_empty();
    end
end
