function [pptApp, prs] = smp_open_pptx(template_path, output_path)
% SMP_OPEN_PPTX  Open a PowerPoint template via COM automation.
%
% Copies the template to output_path, then opens it ready for editing.
% Requires Microsoft PowerPoint to be installed (Windows only).
%
% Usage:
%   [pptApp, prs] = smp_open_pptx('C:\templates\SMP_template.pptx', ...
%                                  'C:\output\SMP_Report_R1.pptx')

    if ~exist(template_path, 'file')
        error('smp_open_pptx: Template not found: %s', template_path);
    end

    % Copy template to output location
    copyfile(template_path, output_path);
    fprintf('Template copied to: %s\n', output_path);

    % Start PowerPoint via COM
    pptApp = actxserver('PowerPoint.Application');
    pptApp.Visible = 1;   % set to 0 for headless if desired

    % Open the copied file
    prs = pptApp.Presentations.Open(output_path, 0, 0, 1);
    fprintf('Presentation opened: %d slides in template.\n', prs.Slides.Count);
end


% ======================================================================= %
function slide = smp_add_slide(prs, layout_index)
% SMP_ADD_SLIDE  Add a new slide using a layout from the template.
%
% Usage:
%   slide = smp_add_slide(prs, 2)   % layout 2 = content layout
%
% layout_index: slide layout index from your template (1=title, 2=content, etc.)
% Inspect your template to find the right index.

    n = prs.Slides.Count;
    slide = prs.Slides.Add(n+1, layout_index);
end


% ======================================================================= %
function smp_set_text(slide, placeholder_idx, text_str)
% SMP_SET_TEXT  Write text to a placeholder on a slide.
%
% Usage:
%   smp_set_text(slide, 1, 'Race 1 Analysis')    % title placeholder
%   smp_set_text(slide, 2, 'SuperSprint - Bathurst')

    try
        ph = slide.Placeholders.Item(placeholder_idx);
        ph.TextFrame.TextRange.Text = text_str;
    catch ME
        fprintf('[smp_set_text] Could not write to placeholder %d: %s\n', ...
            placeholder_idx, ME.message);
    end
end


% ======================================================================= %
function smp_insert_figure(slide, fig, left, top, width, height)
% SMP_INSERT_FIGURE  Export a MATLAB figure and embed it in a slide.
%
% Coordinates are in points (1 inch = 72 points).
% Standard 16:9 slide = 720 x 405 points.
%
% Usage:
%   smp_insert_figure(slide, fig, 36, 80, 648, 290)
%
% Default layout (if called with only slide + fig):
%   smp_insert_figure(slide, fig)   % fills most of the slide

    if nargin < 3, left   = 36;  end   % 0.5 inch margin
    if nargin < 4, top    = 80;  end   % below title area
    if nargin < 5, width  = 648; end   % 9 inch wide
    if nargin < 6, height = 290; end   % proportional

    % Export figure to temp PNG
    tmp = [tempname, '.png'];
    exportgraphics(fig, tmp, 'Resolution', 150, 'BackgroundColor', 'white');

    % Insert into slide
    slide.Shapes.AddPicture(tmp, 0, 1, left, top, width, height);

    % Clean up temp file
    try; delete(tmp); catch; end

    close(fig);   % dispose of the figure handle
end


% ======================================================================= %
function smp_save_close_pptx(pptApp, prs)
% SMP_SAVE_CLOSE_PPTX  Save (overwrite in place) and close the presentation.

    % ppSaveAsOpenXMLPresentation = 24
    prs.Save();
    prs.Close();
    pptApp.Quit();
    delete(pptApp);
    fprintf('Presentation saved and closed.\n');
end
