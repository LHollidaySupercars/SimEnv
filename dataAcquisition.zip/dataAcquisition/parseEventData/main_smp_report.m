%% =========================================================
%  SMP SUPERCARS REPORT — Main Script
%  =========================================================
%  Pipeline:
%    1. Load .ld files via smp_load_teams  →  SMP struct
%    2. Filter runs by session/event/team
%    3. Slice laps via lap_slicer
%    4. Compute per-lap stats via lap_stats
%    5. Interpolate to distance via distance_interp   (optional)
%    6. Plot via create_motorsport_plot
%
%  Data structure produced by smp_load_teams:
%    SMP.(TeamAcronym).meta          table — one row per .ld file
%    SMP.(TeamAcronym).channels{n}   channel struct for run n
%    SMP.(TeamAcronym).info{n}       metadata struct for run n
%
%  Each channel in channels{n} has:
%    .data          (Nx1 double)   physical values
%    .time          (Nx1 double)   seconds from session start
%    .units         (char)
%    .sample_rate   (double, Hz)
%    .raw_name      (char)
%
%  *** REPLACE all values marked *** REPLACE ***
% =========================================================

clear; clc; close all;
addpath(fullfile(pwd, 'functions'));
addpath(fullfile(pwd, 'config'));

% =========================================================
%  SECTION 1 — LOAD DATA
% =========================================================

cfg.data_dir    = 'C:\LOCAL_DATA\01 - SMP\_Team Data';  % *** REPLACE ***
cfg.team_filter = {'XMP'};                        % *** REPLACE: {} = all teams ***

[SMP] = smp_load_teams(cfg.data_dir, cfg.team_filter);

% =========================================================
%  SECTION 2 — SESSION / EVENT FILTER
%  Use SMP.(team).meta table columns to build logical masks.
%  Available columns:
%    Session, Driver, CarNumber, Manufacturer, Vehicle,
%    Venue, Year, LogDate, LoadOK, Missing
% =========================================================
%%

% *** REPLACE: set the session and event you want to analyse ***
TARGET_SESSION = 'Race 1';   % e.g. 'Race 1', 'Qualifying', 'Practice 1'
TARGET_VENUE   = '';          % leave empty to accept any venue

% Build a per-team filtered run index lookup
% Usage: run_idx.(team) = row indices into SMP.(team).channels
teams = fieldnames(SMP);
run_idx = struct();
for t = 1:numel(teams)
    tm   = teams{t};
    meta = SMP.(tm).meta;

    % Start with all loaded, non-missing runs
    mask = meta.LoadOK & ~meta.Missing;

    % Session filter
    if ~isempty(TARGET_SESSION)
        mask = mask & strcmpi(meta.Session, TARGET_SESSION);
    end

    % Venue filter
    if ~isempty(TARGET_VENUE)
        mask = mask & strcmpi(meta.Venue, TARGET_VENUE);
    end

    run_idx.(tm) = find(mask);
    fprintf('%s: %d runs match filter.\n', tm, sum(mask));
end

% =========================================================
%  SECTION 3 — LAP SLICER CONFIG
% =========================================================

lap_opts                = struct();
lap_opts.lap_channel    = 'Lap_Number';  % *** REPLACE if your channel differs ***
lap_opts.min_lap_time   = 60;            % *** REPLACE: minimum plausible lap (s) ***
lap_opts.max_lap_time   = 600;           % *** REPLACE: maximum plausible lap (s) ***
lap_opts.exclude_laps   = [1];           % *** REPLACE: e.g. skip formation/outlap ***
lap_opts.lap_range      = [];            % *** REPLACE: e.g. [2 30] ***
lap_opts.verbose        = false;         % set true for per-lap print

% =========================================================
%  SECTION 4 — CHANNELS TO ANALYSE
%  These are the MATLAB field names after sanitisation by
%  motec_ld_reader. Check fieldnames(SMP.T8R.channels{1})
%  if unsure of exact names.
% =========================================================

channels_of_interest = {
    'Corr_Speed',            % corrected vehicle speed
    'Engine_Speed',          % RPM
    'Throttle_Pedal',        % throttle position (%)
    'Brake_Pressure_Front',  % front brake pressure
    'Gear'};               % gear number
    % 'Steering_Wheel_Angle',
    % 'G_Force_Lat',
    % 'G_Force_Lon',
% };

% =========================================================
%  SECTION 5 — LAP STATS CONFIG
% =========================================================

stats_opts             = struct();
stats_opts.operations  = {'min','max','mean','median','std','var','range','change','initial','final'};
stats_opts.percentiles = [10 90];

% =========================================================
%  SECTION 6 — DISTANCE INTERP CONFIG
% =========================================================

dist_opts                  = struct();
dist_opts.distance_channel = 'Distance';  % *** REPLACE or leave empty to integrate speed ***
dist_opts.distance_scale   = 1.0;         % *** REPLACE: 1000 if channel is in km ***
dist_opts.speed_channel    = 'Corr_Speed';
dist_opts.speed_to_ms      = 1 / 3.6;    % km/h → m/s; set 1.0 if already m/s
dist_opts.resolution       = 1;           % metres between grid points
dist_opts.common_grid      = true;
dist_opts.verbose          = false;

% =========================================================
%  SECTION 7 — COLOURS
% =========================================================

C = colours();

% =========================================================
%  SECTION 8 — MAIN PROCESSING LOOP
%  Loops over each team → each matching run → slices laps
%  → computes stats → stores results in RESULTS struct.
%
%  RESULTS.(team){run_n}.laps        lap_slicer output
%  RESULTS.(team){run_n}.stats       lap_stats output
%  RESULTS.(team){run_n}.laps_dist   distance_interp output (if enabled)
%  RESULTS.(team){run_n}.info        motec_ld_info metadata
% =========================================================

DO_DISTANCE_INTERP = true;   % set false to skip (faster if you only need time-based stats)

RESULTS = struct();

for t = 1:numel(teams)
    tm   = teams{t};
    idxs = run_idx.(tm);

    if isempty(idxs)
        fprintf('[%s] No matching runs — skipping.\n', tm);
        continue;
    end

    RESULTS.(tm) = cell(numel(idxs), 1);

    for r = 1:numel(idxs)
        n       = idxs(r);
        session = SMP.(tm).channels{n};
        info    = SMP.(tm).info{n};

        fprintf('[%s] Run %d  |  %s  |  %s  |  Car %s\n', ...
            tm, n, info.event, info.session, info.car_number);

        res      = struct();
        res.info = info;

        % Step A: Slice into laps
        try
            res.laps = lap_slicer(session, lap_opts);
        catch ME
            fprintf('  [WARN] lap_slicer failed: %s\n', ME.message);
            continue;
        end

        if isempty(res.laps)
            fprintf('  [WARN] No valid laps found.\n');
            continue;
        end

        % Step B: Per-lap statistics
        try
            res.stats = lap_stats(res.laps, channels_of_interest, stats_opts);
        catch ME
            fprintf('  [WARN] lap_stats failed: %s\n', ME.message);
        end

        % Step C: Distance interpolation (optional)
        if DO_DISTANCE_INTERP
            try
                res.laps_dist = distance_interp(res.laps, dist_opts);
            catch ME
                fprintf('  [WARN] distance_interp failed: %s\n', ME.message);
            end
        end

        RESULTS.(tm){r} = res;
    end
end

fprintf('\n=== Processing complete ===\n');
fprintf('Access results via:\n');
fprintf('  RESULTS.T8R{1}.laps                     lap struct array\n');
fprintf('  RESULTS.T8R{1}.stats.Corr_Speed.max     per-lap max speed\n');
fprintf('  RESULTS.T8R{1}.laps_dist(k).dist_vec    distance grid for lap k\n');
fprintf('  RESULTS.T8R{1}.info.driver              driver name\n\n');

% =========================================================
%  SECTION 9 — EXAMPLE PLOTS
%  Uncomment each block to produce a plot.
% =========================================================

%% --- Example: Max speed per lap, one line per team -------------------
%
pd = struct();
i  = 0;
for t = 1:numel(teams)
    tm = teams{t};
    for r = 1:numel(RESULTS.(tm))
        res = RESULTS.(tm){r};
        if isempty(res), continue; end
        i = i + 1;
        pd(i).label       = sprintf('%s Car %s', tm, res.info.car_number);
        pd(i).lap_numbers = res.stats.Corr_Speed.lap_numbers;
        pd(i).values      = res.stats.Corr_Speed.max;
        pd(i).colour      = C.manufacturer(res.info.vehicle_id);
    end
end
cfg_plot = struct('title','Max Speed per Lap','y_label','Speed','units','km/h');
fig = create_motorsport_plot('lap_trend', pd, cfg_plot);

%% --- Example: Box plot — max speed distribution by manufacturer ------
%
% % Collect all max speeds per manufacturer
% mfg_data = struct();
% for t = 1:numel(teams)
%     tm = teams{t};
%     for r = 1:numel(RESULTS.(tm))
%         res = RESULTS.(tm){r};
%         if isempty(res), continue; end
%         mfg = res.info.vehicle_id;   % e.g. 'Ford', 'Chev', 'Toyota'
%         if ~isfield(mfg_data, mfg), mfg_data.(mfg) = []; end
%         mfg_data.(mfg) = [mfg_data.(mfg), res.stats.Corr_Speed.max];
%     end
% end
% mfgs = fieldnames(mfg_data);
% pd   = struct();
% for m = 1:numel(mfgs)
%     pd(m).label  = mfgs{m};
%     pd(m).values = mfg_data.(mfgs{m});
%     pd(m).colour = C.manufacturer(mfgs{m});
% end
% cfg_plot = struct('title','Max Speed Distribution','y_label','Speed','units','km/h');
% fig = create_motorsport_plot('box', pd, cfg_plot);

%% --- Example: Speed trace (distance-based) for one run ---------------
%
% res = RESULTS.T8R{1};   % *** REPLACE team/run index ***
% if ~isempty(res) && isfield(res,'laps_dist')
%     n_laps = numel(res.laps_dist);
%     pd     = struct();
%     pd(1).label  = sprintf('Car %s', res.info.car_number);
%     pd(1).colour = C.manufacturer(res.info.vehicle_id);
%     % Assemble M×L trace matrix
%     n_pts = numel(res.laps_dist(1).dist_vec);
%     pd(1).traces   = NaN(n_pts, n_laps);
%     pd(1).dist_vec = res.laps_dist(1).dist_vec;
%     for k = 1:n_laps
%         d = res.laps_dist(k).channels.Corr_Speed.dist_data;
%         pd(1).traces(1:numel(d), k) = d;
%     end
%     cfg_plot = struct('title','Speed Trace','y_label','Speed','units','km/h');
%     fig = create_motorsport_plot('trace', pd, cfg_plot);
% end

%% --- Example: Falling max speed across all teams ----------------------
%
% pd = struct();
% i  = 0;
% for t = 1:numel(teams)
%     tm = teams{t};
%     for r = 1:numel(RESULTS.(tm))
%         res = RESULTS.(tm){r};
%         if isempty(res), continue; end
%         i = i + 1;
%         pd(i).label  = sprintf('%s Car %s', tm, res.info.car_number);
%         pd(i).values = res.stats.Corr_Speed.max;
%         pd(i).colour = C.manufacturer(res.info.vehicle_id);
%     end
% end
% cfg_plot = struct('title','Falling Max Speed','y_label','Speed','units','km/h');
% fig = create_motorsport_plot('falling_max', pd, cfg_plot);
